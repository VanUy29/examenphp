<?php
class Personne {
    private $nom;
    private $prenom;
    private $date_naissance;

    public function __construct($nom, $prenom, $date_naissance) {
        $this->nom = $nom;
        $this->prenom = $prenom;
        $this->date_naissance = DateTime::createFromFormat('d/m/Y', $date_naissance);
    }

    public function presenter() {
        return "Je m'appelle " . $this->nom . " " . $this->prenom;
    }

    public function age() {
        $today = new DateTime();
        $diff = $today->diff($this->date_naissance);
        return $diff->y;
    }
}

// Test
$personne1 = new Personne("Nguyen Van UY", "Daniel", "29/02/2004");
$personne2 = new Personne("RAKOTOVAO", "Pierre", "15/05/2000");

echo $personne1->presenter() . ", j'ai " . $personne1->age() . " ans.\n";
echo "<br>";
echo $personne2->presenter() . ", j'ai " . $personne2->age() . " ans.\n";
?>
