<?php
echo "<table>";
echo "<tr><th>Variable</th><th>Signification</th><th>Valeur</th></tr>";

// SERVER_ADDR
echo "<tr><td>SERVER_ADDR</td><td>Adresse IP du serveur où le script courant est exécuté.</td><td>" . $_SERVER['SERVER_ADDR'] . "</td></tr>";

// HTTP_HOST
echo "<tr><td>HTTP_HOST</td><td>Nom de l'hôte tel qu'il est fourni dans l'en-tête Host de la requête HTTP courante.</td><td>" . $_SERVER['HTTP_HOST'] . "</td></tr>";

// REMOTE_ADDR
echo "<tr><td>REMOTE_ADDR</td><td>Adresse IP du client qui demande la page vue.</td><td>" . $_SERVER['REMOTE_ADDR'] . "</td></tr>";

// HTTP_USER_AGENT
echo "<tr><td>HTTP_USER_AGENT</td><td>Chaîne d'identification de l'agent utilisateur (browser) utilisé pour voir la page courante.</td><td>" . $_SERVER['HTTP_USER_AGENT'] . "</td></tr>";

echo "</table>";

    
?>

<?php
phpinfo();
?>
