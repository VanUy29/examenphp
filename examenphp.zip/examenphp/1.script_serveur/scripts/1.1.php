
<?php
echo "Hello PHP, nous sommes le " . date("d F Y");
?>


<?php
$heure = date("H");
if ($heure >= 6 && $heure < 12) {
    echo "Bon matin";
} elseif ($heure >= 12 && $heure < 18) {
    echo "Bonne après-midi";
} else {
    echo "Bonne soirée";
}
?>

