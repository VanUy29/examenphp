<?php
if (isset($_POST['texte'])) {
    $texte = nl2br($_POST['texte']);
    echo $texte;
}
?>
