
<?php
if (isset($_GET['submit'])) {
    // Traiter les données ici
    $nom = $_GET['nom'];
    $prenom = $_GET['prenom'];
    $sexe = $_GET['sexe'];
    $vins = $_GET['vins'];
    // Afficher les données
    echo "Nom: $nom<br>Prénom: $prenom<br>Sexe: $sexe<br>Vins: ";
    foreach ($vins as $vin) {
        echo "$vin ";
    }
} else {
    echo '
    <form action="1.6.php" method="get">
        Nom: <input type="text" name="nom"><br>
        Prénom: <input type="text" name="prenom"><br>
        Sexe: <select name="sexe">
            <option value="M">M</option>
            <option value="F">F</option>
        </select><br>
        Vins: <select name="vins[]" multiple>
            <option value="Tana">Tana</option>
            <option value="Antsirabe">Antsirabe</option>
            <option value="Tamatave">Tamatave</option>
        </select><br>
        <input type="hidden" name="submit" value="1">
        <input type="submit" value="Envoyer">
    </form>
    ';
}
?>
