<?php
session_start();
session_destroy();

echo 'Session détruite. <a href="menu.html">Retour au menu</a>';
?>
