<?php
session_start();

echo 'Nom: ' . $_SESSION['nom'] . '<br>';
echo 'Prenom: ' . $_SESSION['prenom'] . '<br>';
echo 'Nombre de visites: ' . $_SESSION['count'] . '<br>';

echo '<a href="menu.html">Retour au menu</a>';
?>
