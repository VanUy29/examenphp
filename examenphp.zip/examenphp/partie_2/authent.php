<?php
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'miniCRUD');

$link = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

if ($link === false) {
    die('Erreur de connexion : ' . mysqli_connect_error());
}


$sql = "SELECT * FROM `authentification`";

if ($result = mysqli_query($link, $sql)) {
    if (mysqli_num_rows($result) > 0) {
        $tableau_pseudo = [];
        $tableau_mdp = [];

        
        while ($row = mysqli_fetch_array($result)) {
            $tableau_pseudo[] = $row['pseudo'];
            $tableau_mdp[] = $row['mdp'];
        }

        mysqli_free_result($result);
    }
}


if (isset($_POST['pseudo']) && isset($_POST['mdp'])) {
    $pseudo = $_POST['pseudo'];
    $mdp = $_POST['mdp'];

 
    if (verif(count($tableau_mdp), $tableau_mdp, $tableau_pseudo, $pseudo, $mdp)) {
        echo 'Authentification réussie !'; // Remplacez par votre propre logique d'authentification
    } else {
        echo 'Identifiants incorrects !'; // Remplacez par votre propre message d'erreur
    }
}


function verif($i, $tableau_mdp, $tableau_pseudo, $pseudo, $mdp) {
    for ($j = 0; $j < $i; $j += 1) {
        if ($pseudo == $tableau_pseudo[$j] && $mdp == $tableau_mdp[$j]) {
            return true;
        }
    }
    return false;
}
?>
