<?php
include 'authent.php';

if(verif($i, $tableau_mdp, $tableau_pseudo , $pseudo , $mdp)){
    $_SESSION['pseudo'];
}