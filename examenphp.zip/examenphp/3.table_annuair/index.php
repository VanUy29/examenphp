<?php
    
    $db = new PDO('mysql:host=localhost;dbname=dbannuaire', 'root', '');

    // 1) Rechercher une entrée dans la table annuaire
    function search($nom, $prenom) {
        global $db;
        $stmt = $db->prepare("SELECT * FROM annuaire WHERE nom LIKE :nom AND prenom LIKE :prenom");
        $stmt->execute(['nom' => $nom.'%', 'prenom' => $prenom.'%']);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // 2) Ajouter une nouvelle entrée dans l'annuaire
    function add($nom, $prenom, $poste) {
        global $db;
        $stmt = $db->prepare("INSERT INTO annuaire (nom, prenom, poste) VALUES (:nom, :prenom, :poste)");
        $stmt->execute(['nom' => $nom, 'prenom' => $prenom, 'poste' => $poste]);
    }

    // 3) Modifier un numéro de poste
    function update($nom, $prenom, $poste) {
        global $db;
        $stmt = $db->prepare("UPDATE annuaire SET poste = :poste WHERE nom = :nom AND prenom = :prenom");
        $stmt->execute(['nom' => $nom, 'prenom' => $prenom, 'poste' => $poste]);
    }

    // 4) Supprimer une entrée de l'annuaire
    function delete($nom, $prenom) {
        global $db;
        $stmt = $db->prepare("DELETE FROM annuaire WHERE nom = :nom AND prenom = :prenom");
        $stmt->execute(['nom' => $nom, 'prenom' => $prenom]);
    }
?>
